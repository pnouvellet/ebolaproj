library(testthat)
library(ebolaproj)

test_check("ebolaproj")
