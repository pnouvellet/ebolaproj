context("example tests")
test_that("1 + 1 = 2", {
  expect_equal(2, 1 + 1)
})

