## ----install, eval=FALSE-------------------------------------------------
#  install.packages("ebolaproj")

## ----install2, eval=FALSE------------------------------------------------
#  devtools::install_github("reconhub/ebolaproj")

